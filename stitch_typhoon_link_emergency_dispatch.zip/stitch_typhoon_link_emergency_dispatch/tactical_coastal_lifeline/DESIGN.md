---
name: Tactical Coastal Lifeline
colors:
  surface: '#0b1229'
  surface-dim: '#0b1229'
  surface-bright: '#323851'
  surface-container-lowest: '#060d24'
  surface-container-low: '#141a32'
  surface-container: '#181e36'
  surface-container-high: '#222941'
  surface-container-highest: '#2d344c'
  on-surface: '#dce1ff'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#dce1ff'
  inverse-on-surface: '#292f48'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#ffb690'
  on-secondary: '#552100'
  secondary-container: '#ec6a06'
  on-secondary-container: '#4a1c00'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#008259'
  on-tertiary-container: '#e1ffec'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0b1229'
  on-background: '#dce1ff'
  surface-variant: '#2d344c'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: 0em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
  telemetry-num:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered for life-critical disaster management, peer-to-peer mesh connectivity, and emergency humanitarian relief during severe cyclone crises along the Eastern seaboard. Built for low-battery environments, drenched touchscreens, torrential rain glare, and high-stress field operations, the aesthetic merges utilitarian mission control with rugged tactical field hardware.

The design movement is **High-Contrast Tactical Utility**: sharp visual hierarchies, functional borders, zero decorative micro-interactions, high luminance contrast ratios (exceeding WCAG AAA standards), and instant state comprehension. The UI conveys authoritative stability, decisive operational clarity, and immediate survival readiness for citizens, first responders, and civic authorities under zero-bandwidth conditions.

## Colors

The system uses a persistent deep dark mode designed to minimize battery drain on OLED devices during multi-day coastal grid collapse, while maximizing daytime luminance through strict stark contrasts.

### Primary Role (Life-Critical Alert & P1 Severity)
- **Primary Alert Base**: `#DC2626` (Crimson Hazard) — reserved exclusively for life-threatening events, emergency SOS broadcasts, and immediate structural collapse warnings.
- **Primary Alert Bright**: `#EF4444` — active strobe states, critical interactive buttons, and P1 beacon indicators.

### Secondary Role (Operational Urgency & P2 Logistics)
- **Safety Orange Base**: `#EA580C` — critical logistical warnings, power grid drops, and rising tidal surges.
- **Rescue Amber Glow**: `#F97316` — mesh peer handshakes, P2 alerts, pending packet queues, and amber telemetry flags.

### Tertiary Role (Safe Havens & Mesh Active States)
- **Evacuation Emerald**: `#10B981` — verified cyclone shelters, active mesh node links, successful packet transmission, and P3 clearance signals.
- **Calm Teal Deep**: `#059669` — secondary confirmations and structural safety validation.

### Neutral & Foundation Roles
- **Canvas Base**: `#0A1128` (Abyssal Navy) — high-absorption root background ensuring deep visual isolation.
- **Surface Elevation 1**: `#0F172A` (Slate Navy) — container cards, tactical panels, and offline navigation headers.
- **Surface Elevation 2**: `#1E293B` — inputs, elevated cards, and modal dialogs.
- **Surface Outline / Grid**: `#334155` — crisp structural boundaries.
- **High-Visibility White**: `#FFFFFF` — text for telemetry values and primary alert labels.
- **Functional Off-White**: `#E2E8F0` — secondary body text and metadata, calibrated against rain-spotted screens.

## Typography

The typographical engine operates on a strict functional dichotomy between human directive text and raw machine telemetry:

- **Inter** commands all narrative, body text, and direct action instructions. Its neutral, high x-height forms guarantee instant recognition under variable ambient conditions, degraded vision, or motion stress.
- **JetBrains Mono** governs all tactical readouts: mesh radio payloads, byte counters, hop limits, coordinate systems (lat/long), timestamps, and priority tags. Tabular numerals (`tnum`) must be enforced across all telemetry fields to prevent layout shifting during high-frequency signal updates.

All critical alerts, SOS signals, and distance counters use uppercase display formatting with tightened tracking to enhance immediate scannability.

## Layout & Spacing

The layout model is anchored in a responsive fluid-column framework prioritizing one-handed field operation and high tap-target precision.

- **Mobile (< 768px):** 4-column layout with 16px (`1rem`) outer margins and gutters. All core actionable buttons (SOS, Shelter Locator, Mesh Link) have a minimum interactive height of 52px to accommodate wet, unsteady, or gloved fingers.
- **Tablet (768px - 1024px):** 8-column layout with split triage panels. The primary column hosts map/mesh telemetry; the secondary column hosts the queue of incoming survivor beacons.
- **Desktop / Command HQ (> 1024px):** 12-column layout with fixed sidebars for continuous mesh topological analysis, persistent incident logs, and weather telemetry.

Spacing rhythm relies on dense, modular multiples of 4px. Information density remains intentionally tight within diagnostic cards to fit vital status points into a single screen viewport without vertical scrolling.

## Elevation & Depth

To conserve GPU power, eliminate visual noise, and guarantee legibility across water-damaged displays, this design system rejects blurry drop shadows and diffuse skeuomorphic blurs. Depth is achieved via **Tonal Tiering & Structural Boundaries**:

- **Ground Level (`#0A1128`):** The primary viewport canvas.
- **Level 1 Panels (`#0F172A` with a 1px border of `#1E293B`):** Standard data cards, historical logs, and map controls.
- **Level 2 Interactive Cards (`#1E293B` with a 1px border of `#334155`):** Selected items, active triage cards, and offline input containers.
- **Hazard Accents:** Active critical panels apply an inset or outset 2px solid border using the respective priority color (`#DC2626` for P1, `#F97316` for P2, `#10B981` for Safe Haven).
- **Overlays & Drawers:** Completely opaque slate surface (`#0F172A`) backed by a pure `#000000` scrim with 85% opacity, fully arresting background movement.

## Shapes

The geometric signature is **Soft/Chiseled (`roundedness: 1`)**. Elements use minimal border radiuses (`0.25rem` / 4px base, up to `0.5rem` / 8px for large containers), evoking rugged field radios, military handhelds, and ruggedized industrial tablets.

Status indicators, priority tags, and byte monitors take the form of razor-precise rectangular tiles or strictly geometric, clipped status pills. Circular elements are restricted strictly to radio frequency beacons, geolocation nodes, and peer connectivity radial graphs.

## Components

### Buttons
- **SOS Critical Button:** Full-width, minimum height 56px. Background in Crimson Alert (`#DC2626`), high-contrast white text (`#FFFFFF`) in `headline-md`, uppercase. Active/press state darkens to `#991B1B`. Includes an optional continuous 2px solid outline pulse.
- **Secondary Action (Rescue/Acknowledge):** Slate fill (`#1E293B`) with a 1px border of `#334155`. Text in off-white (`#E2E8F0`). Focus/active states highlight the border with Safety Orange (`#F97316`).
- **Tactical Utility Controls:** Compact 36px height buttons using `JetBrains Mono` at `label-md` for payload dump, mesh reset, or manual packet resend.

### Priority Badges & Mesh Indicators
- **P1 Critical Badge:** Background `#450A0A`, text `#FCA5A5`, border 1px solid `#DC2626`. Monospaced text: `[P1-CRITICAL]`.
- **P2 Urgent Badge:** Background `#431407`, text `#FDBA74`, border 1px solid `#EA580C`. Monospaced text: `[P2-URGENT]`.
- **P3 Logistical Badge:** Background `#064E3B`, text `#6EE7B7`, border 1px solid `#059669`. Monospaced text: `[P3-ROUTINE]`.
- **Mesh Beacon Pill:** Compact pill housing live connection metrics: dynamic peer counter, signal decibels (dBm), and hop indicator (e.g., `MESH: 14 PEERS | HOP: 2`).

### Telemetry & Hazard Cards
- Base surface of `#0F172A`, 1px solid border `#1E293B`.
- Header houses the signal origin and timestamp using `label-sm`.
- Core data values (cyclone wind speed, surge height, barometric pressure) utilize `telemetry-num` in stark pure white.
- Cards maintain an internal padding of `space-md` (12px) to prevent layout inflation.

### Input Fields
- Deep contrast base (`#0A1128`) with an explicit 1.5px border (`#334155`).
- Active focus state immediately converts the border to Pure White (`#FFFFFF`) or Rescue Amber (`#F97316`) without blur halos.
- Labeling sits strictly above the field using `label-md` to remain clear during quick voice-to-text or hurried thumb-typing.

### Checkboxes & Segmented Toggles
- Custom high-contrast square controls (4px radius).
- Unchecked: `#0F172A` with `#475569` border.
- Checked: `#10B981` fill with `#0A1128` check icon, providing instant affirmative verification.